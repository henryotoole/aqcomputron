# aqcomputron
A fun little project to regulate air quality.
